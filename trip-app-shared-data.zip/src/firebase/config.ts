import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// Fill these in from your Firebase project settings:
// Firebase Console -> Project settings (gear icon) -> General ->
// "Your apps" -> Web app -> SDK setup and configuration -> Config.
// These values are safe to ship in the app — they identify your project,
// they are not secret credentials. Access is controlled by Firestore
// Security Rules instead (see firestore.rules in the repo root).
const firebaseConfig = {
  apiKey: 'REPLACE_ME',
  authDomain: 'REPLACE_ME.firebaseapp.com',
  projectId: 'REPLACE_ME',
  storageBucket: 'REPLACE_ME.appspot.com',
  messagingSenderId: 'REPLACE_ME',
  appId: 'REPLACE_ME',
};

export const firebaseApp = initializeApp(firebaseConfig);
export const db = getFirestore(firebaseApp);
